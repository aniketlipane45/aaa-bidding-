# bidding-website

This project is a joint contribution of [Robin Rawat](https://www.linkedin.com/in/robin-rawat-a0592915b/) and [Rishab Raina](https://www.linkedin.com/in/rishab-raina-56ab20117/)

# Operation:

You can join in to our the website.

Login then place your bid on anyitem available.

Search for item.

Plus you can upload your item for bid if you want to.

# For running the site you need to create a localhost and configure the mysql.

# Running through localhost:

Go to your browser and enter the following url:

*localhost/index1.php*

# Languages:

php

html5

css3

mysql
