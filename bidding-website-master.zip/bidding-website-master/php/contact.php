<!DOCTYPE HTML>
<html>
<body>
<h1><strong>Contact us</strong></h3>
<style>
body {
    background-color: #93B874;
}
</style>
<body>
<h2><pre>

<dl style="list-style-type:circle">
<dt><u>Phone</u></dt>
<dd>+91-1597536248</dd>
<dd>+91-1456328957</dd>
<dt><u>Email</u></dt>
<dd><i>geu_auction@gmail.com</i></dd>
<dd><i>auction_123@hotmail.com</i></dd>
</pre>
</h2>
</body>
</html>
