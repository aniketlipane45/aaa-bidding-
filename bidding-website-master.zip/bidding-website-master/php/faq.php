<!DOCTYPE HTML>
<html>
<style>
body {
    background-color: #93B874;
}
</style>
<body>
<h3><strong>F.A.Q.....</strong></h3>
<body>
<pre>

What are the benefits of registration?

By registering and providing correct contact information, including an email address, you will receive:
Email confirmation of your registration.
Email confirmation of all bids you place, for your records.
Email notification if you are outbid by another bidder, to give you an opportunity to place another, higher bid, and remain an active bidder.
Daily email updates with winning strategies, featured items, and other important information.
Special offers and promotions, such as coupons, from vendors whose items you bid on.
Email and/or telephone notification if you are a winning bidder as soon as the bidding closes.
Option to pay online for your winning bid and immediately receive a certificate.
Personalized certificate for items you win and purchase, for quick and easy redemption.
<hr>
How do I search for and sort items?

You can browse through the categories to view all items in selected categories.
You can search for a specific item by Item Number (e.g. 101).
You can perform a keyword search by item name, item description
I am the winning bidder on several items. Can I pay for them all at once?

No, you must pay for each item as a separate transaction in order to receive an Item Certificate for each item.

<hr>
What methods of payment are accepted online?

You can pay by credit card only.


I don't want to pay for my item(s) online. What other options are available?

You can pay by credit card over the telephone, or in-person. The phone number, address, and hours of operation are in your winner notification email.

<hr>
Why are some items not available for payment online?

The sponsor of this online marketplace or the item vendor may require that payment be made in person for some or all items, particularly automobiles and real estate, where additional information is required from you or where the item must be registered or licensed.
</pre>
</body>
</html>

