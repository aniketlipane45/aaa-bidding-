<!DOCTYPE HTML>
<html>
<style>
body {
    background-color: #93B874;
}
</style>
<body>
<h3>about us</h3>
<pre>
we are a diverse biding company.
we beleive in healthy relationships between seller and buyer.


</pre></body>
</html> 