<!DOCTYPE HTML>
<HTML>
<HEAD></HEAD>
<BODY> welcome! <br>
<b>thanks for registering
<a href="login1.php">login</a>
</BODY>
</HTML>
